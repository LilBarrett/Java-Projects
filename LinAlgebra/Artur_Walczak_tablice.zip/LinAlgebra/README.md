# Operacje na Macierzach w Javie

## Opis Projektu

Projekt demonstruje obiektowe podejście do operacji na macierzach. Zawiera implementację różnych funkcje matematycznych na macierzach, wektorach i skalarach.

## Struktura Katalogów

- `src` - zawiera kod źródłowy
- `lib` - folder na zewnętrzne zależności
- `bin` - wygenerowane pliki wynikowe


package LinAlgebra;

public class Main {
    public static void main(String[] args) {
        // Przykład (to nie są główne testy)
        Vector v1 = new Vector(new double[]{1, 2, 3}, false);
        Vector v2 = new Vector(new double[]{4, 5, 6}, false);
        System.out.println(v1.toString());
        System.out.println(v2.toString());
    }
}